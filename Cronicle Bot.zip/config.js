// Buat Lu Yang Jual Sc Ini Yang Jujur Jangan Samp Nipu Apalagi Lari Dari Tanggung Jawab



const fs = require('fs')
const chalk = require('chalk')
const yargs = require('yargs/yargs')

global.gr = 'https://www.instagram.com/ikyy.mc_'
global.ig = '@ikyy.mc_' // ubah aja
global.email = 'ikyytzy.supp@gmail.com' //serah
global.region = 'Maluku, Indonesia' // serah
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'KZY - ALWAYS' //ubah jadi nama mu, note tanda ' gausah di hapus!

//panel setting
global.domain = 'https://' // Isi Domain Lu
global.aapikey = 'ptla'
global.capikey = 'ptlc' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.gmail = '.ikyybuyer@tempmail.xyz' //email serah mau ganti apa
global.croniclexyz = 'https://telegra.ph/file/0df5fce2fa3e330c3a3ce.png' // buat thumbnail kirim data panel

//=================================================//
global.owner = ['6281246493375'] // ubah aja pake nomor lu
//==========================BY Hw Mods=======================//
global.keyopenai = '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'
//====================BY Hw Mods=============================//
global.botname = 'TheCronicle - Bot' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = '\nIkyyKzy - CRONICLE' // ubah aja ini nama sticker
global.author = 'K Z Y - T E A M' // ubah aja ini nama sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'cronicle' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.ktp = '`'
global.wlcm = []
global.wlcmm = []
global.anticall = true
global.mess = 
{
    success: '_Sukses_ ✅',
    admin: '_Fiture khusus admin group_',
    botAdmin: '_Bot harus menjadi admin terlebih dahulu_',
    owner: '_Fiture khusus owner bot_',
    group: '_Fiture hanya dapat digunakan di group chat_',
    private: '_Fiture hanya dapat digunakan di private chat_',
    bot: '_Fiture khusus pengguna nomor bot_',
    error: '_Mungkin sedang error ka harap lapor owner agar segera di perbaiki 🧑‍🔧_ ',
    wait: '_Sedang Di Proses ..._',
    premium: '_Fiture khusus premium user_',
}
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})